package Entity;

public class Circulo {
    
    private float area;
    private float radio;
    private float perimetro;

    public Circulo(float area, float radio, float perimetro) {
        this.area = area;
        this.radio = radio;
        this.perimetro = perimetro;
    }

    public Circulo() {
    }

    public float getArea() {
        return area;
    }

    public void setArea(float area) {
        this.area = area;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getPerimetro() {
        return perimetro;
    }

    public void setPerimetro(float perimetro) {
        this.perimetro = perimetro;
    }

    @Override
    public String toString() {
        return "Circulo{" + "area=" + area + ", radio=" + radio + ", perimetro=" + perimetro + '}';
    }

       
}
