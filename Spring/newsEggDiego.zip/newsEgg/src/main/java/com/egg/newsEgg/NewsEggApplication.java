package com.egg.newsEgg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsEggApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsEggApplication.class, args);
	}

}
