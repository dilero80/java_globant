/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.egg.newsEgg.Exceptions;

/**
 *
 * @author drome
 */
public class NewsExceptions extends Exception{
    
    public NewsExceptions (String msg){
        super(msg);
    }
    
}
