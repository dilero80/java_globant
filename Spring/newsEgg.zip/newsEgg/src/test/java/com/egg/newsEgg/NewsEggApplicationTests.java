package com.egg.newsEgg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsEggApplicationTests {

	@Test
	void contextLoads() {
	}

}
