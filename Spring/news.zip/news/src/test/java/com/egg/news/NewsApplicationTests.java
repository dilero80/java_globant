package com.egg.news;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
